
let currentPlayer = "X";
let gameBoard = ["", "", "", "", "", "", "", "", ""];
let gameActive = true;
const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];


const cells = document.querySelectorAll(".cell");
const statusDisplay = document.getElementById("status");
const startbutton=document.getElementById("startButton");
const resetButton = document.getElementById("resetButton");

function initializeGame() {
    cells.forEach(cell => {
        cell.innerHTML = "";
        cell.addEventListener("click", handleCellClick);
    });
    statusDisplay.innerHTML = `It's ${currentPlayer}'s turn`;
    gameBoard = ["", "", "", "", "", "", "", "", ""];
    gameActive = true;
}


function handleCellClick(event) {
    const clickedCell = event.target;
    const clickedIndex = parseInt(clickedCell.getAttribute("data-index"));

    if (gameBoard[clickedIndex] !== "" || !gameActive) {
        return;
    }

    gameBoard[clickedIndex] = currentPlayer;
    clickedCell.innerHTML = currentPlayer;

    checkWinner();
}


function checkWinner() {
    let roundWon = false;

    for (let i = 0; i < winningConditions.length; i++) {
        const [a, b, c] = winningConditions[i];
        if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
            roundWon = true;
            break;
        }
    }

    if (roundWon) {
        statusDisplay.innerHTML = `Player ${currentPlayer} wins!`;
        gameActive = false;
        return;
    }

    
    if (!gameBoard.includes("")) {
        statusDisplay.innerHTML = `It's a draw!`;
        gameActive = false;
        return;
    }


    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusDisplay.innerHTML = `It's ${currentPlayer}'s turn`;
}
function resetGame() {
    currentPlayer = "X";
    initializeGame();
}


resetButton.addEventListener("click", resetGame);

initializeGame();
